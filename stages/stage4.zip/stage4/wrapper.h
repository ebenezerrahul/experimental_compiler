#include <stdlib.h>
#include <stdio.h>

void* myMalloc(size_t size);
